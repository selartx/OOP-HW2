﻿/****************************************************************************
**					        SAKARYA ÜNİVERSİTESİ
**			         BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				        BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				          Object Oriented Programming
**	
**				ÖDEV NUMARASI:OOPHW2
**				ÖĞRENCİ ADI:Selva Artunç
**				ÖĞRENCİ NUMARASI:Homework 2
**				DERS GRUBU:1/C
****************************************************************************/
namespace OOPQ2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            comboBox1 = new ComboBox();
            PointX = new TextBox();
            Point = new Label();
            X = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            PointY = new TextBox();
            PointZ = new TextBox();
            label7 = new Label();
            Rectangle1X = new TextBox();
            Rectangle1Y = new TextBox();
            Rectangle1W = new TextBox();
            Rectangle1H = new TextBox();
            Detect = new Button();
            Rectangle2 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            Rectangle2X = new TextBox();
            Rectangle2Y = new TextBox();
            Circle1X = new TextBox();
            Rectangle2H = new TextBox();
            Rectangle2W = new TextBox();
            Circle1Y = new TextBox();
            Circle2Y = new TextBox();
            CircleR = new TextBox();
            Circle2X = new TextBox();
            Circle2R = new TextBox();
            label8 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            Sphere1X = new TextBox();
            Sphere1Y = new TextBox();
            Sphere2Z = new TextBox();
            Sphere2Y = new TextBox();
            Sphere2X = new TextBox();
            Sphere1Z = new TextBox();
            Sphere2R = new TextBox();
            Sphere1R = new TextBox();
            Quadrangular2Z = new TextBox();
            Quadrangular2Y = new TextBox();
            Quadrangular2X = new TextBox();
            Quadrangular1D = new TextBox();
            Quadrangular1H = new TextBox();
            Quadrangular1W = new TextBox();
            Quadrangular1Z = new TextBox();
            Quadrangular1Y = new TextBox();
            Quadrangular1X = new TextBox();
            Quadrangular2W = new TextBox();
            Quadrangular2H = new TextBox();
            Quadrangular2D = new TextBox();
            Cylinder1R = new TextBox();
            Cylinder2Z = new TextBox();
            Cylinder2Y = new TextBox();
            Cylinder2X = new TextBox();
            Cylinder1H = new TextBox();
            Cylinder1Z = new TextBox();
            Cylinder1Y = new TextBox();
            Cylinder1X = new TextBox();
            Cylinder2R = new TextBox();
            Cylinder2H = new TextBox();
            SurfaceZ = new TextBox();
            SurfaceY = new TextBox();
            SurfaceX = new TextBox();
            SurfaceW = new TextBox();
            SurfaceH = new TextBox();
            SurfaceD = new TextBox();
            Add = new Button();
            Clear = new Button();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            radioButton5 = new RadioButton();
            radioButton6 = new RadioButton();
            radioButton7 = new RadioButton();
            radioButton8 = new RadioButton();
            label24 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.Info;
            pictureBox1.Location = new System.Drawing.Point(130, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(635, 770);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new System.Drawing.Point(880, 62);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(462, 28);
            comboBox1.TabIndex = 10;
            // 
            // PointX
            // 
            PointX.Location = new System.Drawing.Point(880, 172);
            PointX.Name = "PointX";
            PointX.Size = new Size(61, 27);
            PointX.TabIndex = 11;
            // 
            // Point
            // 
            Point.AutoSize = true;
            Point.Location = new System.Drawing.Point(808, 176);
            Point.Name = "Point";
            Point.Size = new Size(42, 20);
            Point.TabIndex = 12;
            Point.Text = "Point";
            // 
            // X
            // 
            X.AutoSize = true;
            X.Location = new System.Drawing.Point(908, 149);
            X.Name = "X";
            X.Size = new Size(18, 20);
            X.TabIndex = 13;
            X.Text = "X";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(998, 149);
            label1.Name = "label1";
            label1.Size = new Size(17, 20);
            label1.TabIndex = 14;
            label1.Text = "Y";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(1082, 149);
            label2.Name = "label2";
            label2.Size = new Size(18, 20);
            label2.TabIndex = 15;
            label2.Text = "Z";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(1133, 149);
            label3.Name = "label3";
            label3.Size = new Size(49, 20);
            label3.TabIndex = 16;
            label3.Text = "Width";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(1205, 149);
            label4.Name = "label4";
            label4.Size = new Size(54, 20);
            label4.TabIndex = 17;
            label4.Text = "Height";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(1273, 149);
            label5.Name = "label5";
            label5.Size = new Size(50, 20);
            label5.TabIndex = 18;
            label5.Text = "Depth";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(1341, 149);
            label6.Name = "label6";
            label6.Size = new Size(53, 20);
            label6.TabIndex = 19;
            label6.Text = "Radius";
            // 
            // PointY
            // 
            PointY.Location = new System.Drawing.Point(966, 172);
            PointY.Name = "PointY";
            PointY.Size = new Size(73, 27);
            PointY.TabIndex = 20;
            // 
            // PointZ
            // 
            PointZ.Location = new System.Drawing.Point(1056, 176);
            PointZ.Name = "PointZ";
            PointZ.Size = new Size(70, 27);
            PointZ.TabIndex = 21;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(784, 216);
            label7.Name = "label7";
            label7.Size = new Size(87, 20);
            label7.TabIndex = 22;
            label7.Text = "Rectangle 1";
            // 
            // Rectangle1X
            // 
            Rectangle1X.Location = new System.Drawing.Point(880, 213);
            Rectangle1X.Name = "Rectangle1X";
            Rectangle1X.Size = new Size(61, 27);
            Rectangle1X.TabIndex = 23;
            // 
            // Rectangle1Y
            // 
            Rectangle1Y.Location = new System.Drawing.Point(966, 216);
            Rectangle1Y.Name = "Rectangle1Y";
            Rectangle1Y.Size = new Size(73, 27);
            Rectangle1Y.TabIndex = 24;
            // 
            // Rectangle1W
            // 
            Rectangle1W.Location = new System.Drawing.Point(1133, 213);
            Rectangle1W.Name = "Rectangle1W";
            Rectangle1W.Size = new Size(49, 27);
            Rectangle1W.TabIndex = 25;
            // 
            // Rectangle1H
            // 
            Rectangle1H.Location = new System.Drawing.Point(1205, 213);
            Rectangle1H.Name = "Rectangle1H";
            Rectangle1H.Size = new Size(54, 27);
            Rectangle1H.TabIndex = 26;
            // 
            // Detect
            // 
            Detect.Location = new System.Drawing.Point(952, 22);
            Detect.Name = "Detect";
            Detect.Size = new Size(307, 29);
            Detect.TabIndex = 27;
            Detect.Text = "Detect";
            Detect.UseVisualStyleBackColor = true;
            Detect.Click += Detect_Click;
            // 
            // Rectangle2
            // 
            Rectangle2.AutoSize = true;
            Rectangle2.Location = new System.Drawing.Point(780, 264);
            Rectangle2.Name = "Rectangle2";
            Rectangle2.Size = new Size(87, 20);
            Rectangle2.TabIndex = 28;
            Rectangle2.Text = "Rectangle 2";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new System.Drawing.Point(804, 326);
            label9.Name = "label9";
            label9.Size = new Size(58, 20);
            label9.TabIndex = 29;
            label9.Text = "Circle 1";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new System.Drawing.Point(804, 371);
            label10.Name = "label10";
            label10.Size = new Size(58, 20);
            label10.TabIndex = 30;
            label10.Text = "Circle 2";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new System.Drawing.Point(804, 414);
            label11.Name = "label11";
            label11.Size = new Size(67, 20);
            label11.TabIndex = 31;
            label11.Text = "Sphere 1";
            // 
            // Rectangle2X
            // 
            Rectangle2X.Location = new System.Drawing.Point(880, 264);
            Rectangle2X.Name = "Rectangle2X";
            Rectangle2X.Size = new Size(61, 27);
            Rectangle2X.TabIndex = 32;
            // 
            // Rectangle2Y
            // 
            Rectangle2Y.Location = new System.Drawing.Point(966, 267);
            Rectangle2Y.Name = "Rectangle2Y";
            Rectangle2Y.Size = new Size(73, 27);
            Rectangle2Y.TabIndex = 33;
            // 
            // Circle1X
            // 
            Circle1X.Location = new System.Drawing.Point(880, 323);
            Circle1X.Name = "Circle1X";
            Circle1X.Size = new Size(61, 27);
            Circle1X.TabIndex = 34;
            // 
            // Rectangle2H
            // 
            Rectangle2H.Location = new System.Drawing.Point(1205, 267);
            Rectangle2H.Name = "Rectangle2H";
            Rectangle2H.Size = new Size(54, 27);
            Rectangle2H.TabIndex = 35;
            // 
            // Rectangle2W
            // 
            Rectangle2W.Location = new System.Drawing.Point(1133, 267);
            Rectangle2W.Name = "Rectangle2W";
            Rectangle2W.Size = new Size(49, 27);
            Rectangle2W.TabIndex = 36;
            // 
            // Circle1Y
            // 
            Circle1Y.Location = new System.Drawing.Point(966, 320);
            Circle1Y.Name = "Circle1Y";
            Circle1Y.Size = new Size(73, 27);
            Circle1Y.TabIndex = 37;
            // 
            // Circle2Y
            // 
            Circle2Y.Location = new System.Drawing.Point(966, 364);
            Circle2Y.Name = "Circle2Y";
            Circle2Y.Size = new Size(73, 27);
            Circle2Y.TabIndex = 38;
            // 
            // CircleR
            // 
            CircleR.Location = new System.Drawing.Point(1341, 316);
            CircleR.Name = "CircleR";
            CircleR.Size = new Size(69, 27);
            CircleR.TabIndex = 39;
            // 
            // Circle2X
            // 
            Circle2X.Location = new System.Drawing.Point(880, 364);
            Circle2X.Name = "Circle2X";
            Circle2X.Size = new Size(61, 27);
            Circle2X.TabIndex = 40;
            // 
            // Circle2R
            // 
            Circle2R.Location = new System.Drawing.Point(1341, 364);
            Circle2R.Name = "Circle2R";
            Circle2R.Size = new Size(69, 27);
            Circle2R.TabIndex = 41;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(800, 450);
            label8.Name = "label8";
            label8.Size = new Size(67, 20);
            label8.TabIndex = 42;
            label8.Text = "Sphere 2";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new System.Drawing.Point(775, 494);
            label12.Name = "label12";
            label12.Size = new Size(108, 20);
            label12.TabIndex = 43;
            label12.Text = "Quadrangular1";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new System.Drawing.Point(771, 542);
            label13.Name = "label13";
            label13.Size = new Size(112, 20);
            label13.TabIndex = 44;
            label13.Text = "Quadrangular 2";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new System.Drawing.Point(792, 676);
            label14.Name = "label14";
            label14.Size = new Size(58, 20);
            label14.TabIndex = 45;
            label14.Text = "Surface";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new System.Drawing.Point(787, 592);
            label15.Name = "label15";
            label15.Size = new Size(75, 20);
            label15.TabIndex = 46;
            label15.Text = "Cylinder 1";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new System.Drawing.Point(784, 631);
            label16.Name = "label16";
            label16.Size = new Size(75, 20);
            label16.TabIndex = 47;
            label16.Text = "Cylinder 2";
            // 
            // Sphere1X
            // 
            Sphere1X.Location = new System.Drawing.Point(880, 411);
            Sphere1X.Name = "Sphere1X";
            Sphere1X.Size = new Size(61, 27);
            Sphere1X.TabIndex = 48;
            // 
            // Sphere1Y
            // 
            Sphere1Y.Location = new System.Drawing.Point(966, 414);
            Sphere1Y.Name = "Sphere1Y";
            Sphere1Y.Size = new Size(73, 27);
            Sphere1Y.TabIndex = 49;
            // 
            // Sphere2Z
            // 
            Sphere2Z.Location = new System.Drawing.Point(1056, 451);
            Sphere2Z.Name = "Sphere2Z";
            Sphere2Z.Size = new Size(70, 27);
            Sphere2Z.TabIndex = 50;
            // 
            // Sphere2Y
            // 
            Sphere2Y.Location = new System.Drawing.Point(966, 451);
            Sphere2Y.Name = "Sphere2Y";
            Sphere2Y.Size = new Size(73, 27);
            Sphere2Y.TabIndex = 51;
            // 
            // Sphere2X
            // 
            Sphere2X.Location = new System.Drawing.Point(880, 447);
            Sphere2X.Name = "Sphere2X";
            Sphere2X.Size = new Size(61, 27);
            Sphere2X.TabIndex = 52;
            // 
            // Sphere1Z
            // 
            Sphere1Z.Location = new System.Drawing.Point(1056, 414);
            Sphere1Z.Name = "Sphere1Z";
            Sphere1Z.Size = new Size(70, 27);
            Sphere1Z.TabIndex = 53;
            // 
            // Sphere2R
            // 
            Sphere2R.Location = new System.Drawing.Point(1341, 451);
            Sphere2R.Name = "Sphere2R";
            Sphere2R.Size = new Size(69, 27);
            Sphere2R.TabIndex = 54;
            // 
            // Sphere1R
            // 
            Sphere1R.Location = new System.Drawing.Point(1341, 407);
            Sphere1R.Name = "Sphere1R";
            Sphere1R.Size = new Size(69, 27);
            Sphere1R.TabIndex = 55;
            // 
            // Quadrangular2Z
            // 
            Quadrangular2Z.Location = new System.Drawing.Point(1056, 542);
            Quadrangular2Z.Name = "Quadrangular2Z";
            Quadrangular2Z.Size = new Size(70, 27);
            Quadrangular2Z.TabIndex = 56;
            // 
            // Quadrangular2Y
            // 
            Quadrangular2Y.Location = new System.Drawing.Point(966, 542);
            Quadrangular2Y.Name = "Quadrangular2Y";
            Quadrangular2Y.Size = new Size(73, 27);
            Quadrangular2Y.TabIndex = 57;
            // 
            // Quadrangular2X
            // 
            Quadrangular2X.Location = new System.Drawing.Point(880, 539);
            Quadrangular2X.Name = "Quadrangular2X";
            Quadrangular2X.Size = new Size(61, 27);
            Quadrangular2X.TabIndex = 58;
            // 
            // Quadrangular1D
            // 
            Quadrangular1D.Location = new System.Drawing.Point(1273, 491);
            Quadrangular1D.Name = "Quadrangular1D";
            Quadrangular1D.Size = new Size(50, 27);
            Quadrangular1D.TabIndex = 59;
            // 
            // Quadrangular1H
            // 
            Quadrangular1H.Location = new System.Drawing.Point(1205, 491);
            Quadrangular1H.Name = "Quadrangular1H";
            Quadrangular1H.Size = new Size(54, 27);
            Quadrangular1H.TabIndex = 60;
            // 
            // Quadrangular1W
            // 
            Quadrangular1W.Location = new System.Drawing.Point(1133, 494);
            Quadrangular1W.Name = "Quadrangular1W";
            Quadrangular1W.Size = new Size(49, 27);
            Quadrangular1W.TabIndex = 61;
            // 
            // Quadrangular1Z
            // 
            Quadrangular1Z.Location = new System.Drawing.Point(1056, 494);
            Quadrangular1Z.Name = "Quadrangular1Z";
            Quadrangular1Z.Size = new Size(70, 27);
            Quadrangular1Z.TabIndex = 62;
            // 
            // Quadrangular1Y
            // 
            Quadrangular1Y.Location = new System.Drawing.Point(966, 494);
            Quadrangular1Y.Name = "Quadrangular1Y";
            Quadrangular1Y.Size = new Size(73, 27);
            Quadrangular1Y.TabIndex = 63;
            // 
            // Quadrangular1X
            // 
            Quadrangular1X.Location = new System.Drawing.Point(880, 491);
            Quadrangular1X.Name = "Quadrangular1X";
            Quadrangular1X.Size = new Size(61, 27);
            Quadrangular1X.TabIndex = 64;
            // 
            // Quadrangular2W
            // 
            Quadrangular2W.Location = new System.Drawing.Point(1133, 542);
            Quadrangular2W.Name = "Quadrangular2W";
            Quadrangular2W.Size = new Size(49, 27);
            Quadrangular2W.TabIndex = 65;
            // 
            // Quadrangular2H
            // 
            Quadrangular2H.Location = new System.Drawing.Point(1205, 542);
            Quadrangular2H.Name = "Quadrangular2H";
            Quadrangular2H.Size = new Size(54, 27);
            Quadrangular2H.TabIndex = 66;
            // 
            // Quadrangular2D
            // 
            Quadrangular2D.Location = new System.Drawing.Point(1273, 542);
            Quadrangular2D.Name = "Quadrangular2D";
            Quadrangular2D.Size = new Size(50, 27);
            Quadrangular2D.TabIndex = 67;
            // 
            // Cylinder1R
            // 
            Cylinder1R.Location = new System.Drawing.Point(1341, 592);
            Cylinder1R.Name = "Cylinder1R";
            Cylinder1R.Size = new Size(69, 27);
            Cylinder1R.TabIndex = 68;
            // 
            // Cylinder2Z
            // 
            Cylinder2Z.Location = new System.Drawing.Point(1056, 631);
            Cylinder2Z.Name = "Cylinder2Z";
            Cylinder2Z.Size = new Size(70, 27);
            Cylinder2Z.TabIndex = 69;
            // 
            // Cylinder2Y
            // 
            Cylinder2Y.Location = new System.Drawing.Point(966, 631);
            Cylinder2Y.Name = "Cylinder2Y";
            Cylinder2Y.Size = new Size(73, 27);
            Cylinder2Y.TabIndex = 70;
            // 
            // Cylinder2X
            // 
            Cylinder2X.Location = new System.Drawing.Point(880, 628);
            Cylinder2X.Name = "Cylinder2X";
            Cylinder2X.Size = new Size(61, 27);
            Cylinder2X.TabIndex = 71;
            // 
            // Cylinder1H
            // 
            Cylinder1H.Location = new System.Drawing.Point(1205, 585);
            Cylinder1H.Name = "Cylinder1H";
            Cylinder1H.Size = new Size(54, 27);
            Cylinder1H.TabIndex = 72;
            // 
            // Cylinder1Z
            // 
            Cylinder1Z.Location = new System.Drawing.Point(1056, 592);
            Cylinder1Z.Name = "Cylinder1Z";
            Cylinder1Z.Size = new Size(70, 27);
            Cylinder1Z.TabIndex = 73;
            // 
            // Cylinder1Y
            // 
            Cylinder1Y.Location = new System.Drawing.Point(966, 592);
            Cylinder1Y.Name = "Cylinder1Y";
            Cylinder1Y.Size = new Size(73, 27);
            Cylinder1Y.TabIndex = 74;
            // 
            // Cylinder1X
            // 
            Cylinder1X.Location = new System.Drawing.Point(880, 585);
            Cylinder1X.Name = "Cylinder1X";
            Cylinder1X.Size = new Size(61, 27);
            Cylinder1X.TabIndex = 75;
            // 
            // Cylinder2R
            // 
            Cylinder2R.Location = new System.Drawing.Point(1341, 631);
            Cylinder2R.Name = "Cylinder2R";
            Cylinder2R.Size = new Size(69, 27);
            Cylinder2R.TabIndex = 76;
            // 
            // Cylinder2H
            // 
            Cylinder2H.Location = new System.Drawing.Point(1205, 624);
            Cylinder2H.Name = "Cylinder2H";
            Cylinder2H.Size = new Size(54, 27);
            Cylinder2H.TabIndex = 77;
            // 
            // SurfaceZ
            // 
            SurfaceZ.Location = new System.Drawing.Point(1056, 664);
            SurfaceZ.Name = "SurfaceZ";
            SurfaceZ.Size = new Size(70, 27);
            SurfaceZ.TabIndex = 78;
            // 
            // SurfaceY
            // 
            SurfaceY.Location = new System.Drawing.Point(966, 669);
            SurfaceY.Name = "SurfaceY";
            SurfaceY.Size = new Size(73, 27);
            SurfaceY.TabIndex = 79;
            // 
            // SurfaceX
            // 
            SurfaceX.Location = new System.Drawing.Point(880, 669);
            SurfaceX.Name = "SurfaceX";
            SurfaceX.Size = new Size(61, 27);
            SurfaceX.TabIndex = 80;
            // 
            // SurfaceW
            // 
            SurfaceW.Location = new System.Drawing.Point(1133, 664);
            SurfaceW.Name = "SurfaceW";
            SurfaceW.Size = new Size(49, 27);
            SurfaceW.TabIndex = 81;
            // 
            // SurfaceH
            // 
            SurfaceH.Location = new System.Drawing.Point(1205, 664);
            SurfaceH.Name = "SurfaceH";
            SurfaceH.Size = new Size(54, 27);
            SurfaceH.TabIndex = 82;
            // 
            // SurfaceD
            // 
            SurfaceD.Location = new System.Drawing.Point(1273, 664);
            SurfaceD.Name = "SurfaceD";
            SurfaceD.Size = new Size(50, 27);
            SurfaceD.TabIndex = 84;
            // 
            // Add
            // 
            Add.Location = new System.Drawing.Point(7, 290);
            Add.Name = "Add";
            Add.Size = new Size(94, 29);
            Add.TabIndex = 97;
            Add.Text = "Add";
            Add.UseVisualStyleBackColor = true;
            Add.Click += Add_Click;
            // 
            // Clear
            // 
            Clear.Location = new System.Drawing.Point(7, 326);
            Clear.Name = "Clear";
            Clear.Size = new Size(94, 29);
            Clear.TabIndex = 98;
            Clear.Text = "Clear";
            Clear.UseVisualStyleBackColor = true;
            Clear.Click += Clear_Click;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new System.Drawing.Point(7, 45);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(63, 24);
            radioButton1.TabIndex = 137;
            radioButton1.TabStop = true;
            radioButton1.Text = "Point";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new System.Drawing.Point(7, 75);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(82, 24);
            radioButton2.TabIndex = 138;
            radioButton2.TabStop = true;
            radioButton2.Text = "Point3D";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new System.Drawing.Point(7, 105);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(96, 24);
            radioButton3.TabIndex = 139;
            radioButton3.TabStop = true;
            radioButton3.Text = "Rectangle";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Location = new System.Drawing.Point(7, 135);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(67, 24);
            radioButton4.TabIndex = 140;
            radioButton4.TabStop = true;
            radioButton4.Text = "Circle";
            radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.Location = new System.Drawing.Point(7, 165);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(76, 24);
            radioButton5.TabIndex = 141;
            radioButton5.TabStop = true;
            radioButton5.Text = "Sphere";
            radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            radioButton6.AutoSize = true;
            radioButton6.Location = new System.Drawing.Point(7, 195);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(121, 24);
            radioButton6.TabIndex = 142;
            radioButton6.TabStop = true;
            radioButton6.Text = "Quadrangular";
            radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            radioButton7.AutoSize = true;
            radioButton7.Location = new System.Drawing.Point(7, 225);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(84, 24);
            radioButton7.TabIndex = 143;
            radioButton7.TabStop = true;
            radioButton7.Text = "Cylinder";
            radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            radioButton8.AutoSize = true;
            radioButton8.Location = new System.Drawing.Point(7, 260);
            radioButton8.Name = "radioButton8";
            radioButton8.Size = new Size(79, 24);
            radioButton8.TabIndex = 144;
            radioButton8.TabStop = true;
            radioButton8.Text = "Surface";
            radioButton8.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new System.Drawing.Point(13, 762);
            label24.Name = "label24";
            label24.Size = new Size(90, 20);
            label24.TabIndex = 145;
            label24.Text = "B231210019";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1432, 793);
            Controls.Add(label24);
            Controls.Add(radioButton8);
            Controls.Add(radioButton7);
            Controls.Add(radioButton6);
            Controls.Add(radioButton5);
            Controls.Add(radioButton4);
            Controls.Add(radioButton3);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(Clear);
            Controls.Add(Add);
            Controls.Add(SurfaceD);
            Controls.Add(SurfaceH);
            Controls.Add(SurfaceW);
            Controls.Add(SurfaceX);
            Controls.Add(SurfaceY);
            Controls.Add(SurfaceZ);
            Controls.Add(Cylinder2H);
            Controls.Add(Cylinder2R);
            Controls.Add(Cylinder1X);
            Controls.Add(Cylinder1Y);
            Controls.Add(Cylinder1Z);
            Controls.Add(Cylinder1H);
            Controls.Add(Cylinder2X);
            Controls.Add(Cylinder2Y);
            Controls.Add(Cylinder2Z);
            Controls.Add(Cylinder1R);
            Controls.Add(Quadrangular2D);
            Controls.Add(Quadrangular2H);
            Controls.Add(Quadrangular2W);
            Controls.Add(Quadrangular1X);
            Controls.Add(Quadrangular1Y);
            Controls.Add(Quadrangular1Z);
            Controls.Add(Quadrangular1W);
            Controls.Add(Quadrangular1H);
            Controls.Add(Quadrangular1D);
            Controls.Add(Quadrangular2X);
            Controls.Add(Quadrangular2Y);
            Controls.Add(Quadrangular2Z);
            Controls.Add(Sphere1R);
            Controls.Add(Sphere2R);
            Controls.Add(Sphere1Z);
            Controls.Add(Sphere2X);
            Controls.Add(Sphere2Y);
            Controls.Add(Sphere2Z);
            Controls.Add(Sphere1Y);
            Controls.Add(Sphere1X);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label8);
            Controls.Add(Circle2R);
            Controls.Add(Circle2X);
            Controls.Add(CircleR);
            Controls.Add(Circle2Y);
            Controls.Add(Circle1Y);
            Controls.Add(Rectangle2W);
            Controls.Add(Rectangle2H);
            Controls.Add(Circle1X);
            Controls.Add(Rectangle2Y);
            Controls.Add(Rectangle2X);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(Rectangle2);
            Controls.Add(Detect);
            Controls.Add(Rectangle1H);
            Controls.Add(Rectangle1W);
            Controls.Add(Rectangle1Y);
            Controls.Add(Rectangle1X);
            Controls.Add(label7);
            Controls.Add(PointZ);
            Controls.Add(PointY);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(X);
            Controls.Add(Point);
            Controls.Add(PointX);
            Controls.Add(comboBox1);
            Controls.Add(pictureBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private ComboBox comboBox1;
        private TextBox PointX;
        private Label Point;
        private Label X;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox PointY;
        private TextBox PointZ;
        private Label label7;
        private TextBox Rectangle1X;
        private TextBox Rectangle1Y;
        private TextBox Rectangle1W;
        private TextBox Rectangle1H;
        private Button Detect;
        private Label Rectangle2;
        private Label label9;
        private Label label10;
        private Label label11;
        private TextBox Rectangle2X;
        private TextBox Rectangle2Y;
        private TextBox Circle1X;
        private TextBox Rectangle2H;
        private TextBox Rectangle2W;
        private TextBox Circle1Y;
        private TextBox Circle2Y;
        private TextBox CircleR;
        private TextBox Circle2X;
        private TextBox Circle2R;
        private Label label8;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private TextBox Sphere1X;
        private TextBox Sphere1Y;
        private TextBox Sphere2Z;
        private TextBox Sphere2Y;
        private TextBox Sphere2X;
        private TextBox Sphere1Z;
        private TextBox Sphere2R;
        private TextBox Sphere1R;
        private TextBox Quadrangular2Z;
        private TextBox Quadrangular2Y;
        private TextBox Quadrangular2X;
        private TextBox Quadrangular1D;
        private TextBox Quadrangular1H;
        private TextBox Quadrangular1W;
        private TextBox Quadrangular1Z;
        private TextBox Quadrangular1Y;
        private TextBox Quadrangular1X;
        private TextBox Quadrangular2W;
        private TextBox Quadrangular2H;
        private TextBox Quadrangular2D;
        private TextBox Cylinder1R;
        private TextBox Cylinder2Z;
        private TextBox Cylinder2Y;
        private TextBox Cylinder2X;
        private TextBox Cylinder1H;
        private TextBox Cylinder1Z;
        private TextBox Cylinder1Y;
        private TextBox Cylinder1X;
        private TextBox Cylinder2R;
        private TextBox Cylinder2H;
        private TextBox SurfaceZ;
        private TextBox SurfaceY;
        private TextBox SurfaceX;
        private TextBox SurfaceW;
        private TextBox SurfaceH;
        private TextBox SurfaceD;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Button Add;
        private Button Clear;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private RadioButton radioButton5;
        private RadioButton radioButton6;
        private RadioButton radioButton7;
        private RadioButton radioButton8;
        private Label label24;
    }
}
